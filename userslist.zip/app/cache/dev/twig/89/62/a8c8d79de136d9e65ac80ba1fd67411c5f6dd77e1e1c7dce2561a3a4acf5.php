<?php

/* UsersBundle:Users:details.html.twig */
class __TwigTemplate_8962a8c8d79de136d9e65ac80ba1fd67411c5f6dd77e1e1c7dce2561a3a4acf5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "UsersBundle:Users:details.html.twig", 1);
        $this->blocks = array(
            'pageContent' => array($this, 'block_pageContent'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_pageContent($context, array $blocks = array())
    {
        // line 3
        echo "    <!-- Page Content -->
    <div class=\"container\">

        <div class=\"row\">

            <div class=\"col-md-3\">
                <p class=\"lead\"><a href=\"/users/web\">Users</a></p>
                <div class=\"list-group\">
                    <a href=\"/users/web/?gender=m\" class=\"list-group-item\">Male</a>
                    <a href=\"/users/web/?gender=f\" class=\"list-group-item\">Female</a>
                </div>
            </div>

            <div class=\"col-md-9\">
                <div class=\"row\">
                    
                    <div style=\"margin-bottom: 10px;margin-left:29px;\">
                    <form method =\"get\" action=\"/users/web\">
                        <input type=\"text\" name=\"name\"/>
                        <button type=\"submit\">Search First Name</button>
                    </form>
                    </div>
                    ";
        // line 25
        if ($this->getAttribute((isset($context["users"]) ? $context["users"] : null), "errors", array(), "any", true, true)) {
            // line 26
            echo "                        ";
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["users"]) ? $context["users"] : $this->getContext($context, "users")), "errors", array()));
            foreach ($context['_seq'] as $context["_key"] => $context["error"]) {
                // line 27
                echo "                            <p class=\"error\">";
                echo twig_escape_filter($this->env, $context["error"], "html", null, true);
                echo "</p>
                        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['error'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 29
            echo "                                             
                    ";
        } else {
            // line 30
            echo "                   
                    <p class=\"col-lg-4\">User details</p>                  
                    </div>
                            
                    <div class=\"col-sm-4 col-lg-4 col-md-4\">
                        <div class=\"thumbnail\">
                            <img src=\"http://placehold.it/320x150\" alt=\"\">
                            <div class=\"caption\">
                                <h4 class=\"pull-right\">";
            // line 38
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["userDetails"]) ? $context["userDetails"] : $this->getContext($context, "userDetails")), "last_name", array()), "html", null, true);
            echo "</h4>
                                <h4><a href=\"/users/web/edit/";
            // line 39
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["userDetails"]) ? $context["userDetails"] : $this->getContext($context, "userDetails")), "id", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["userDetails"]) ? $context["userDetails"] : $this->getContext($context, "userDetails")), "first_name", array()), "html", null, true);
            echo "</a>
                                </h4>
                                <p>Birthdate: ";
            // line 41
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["userDetails"]) ? $context["userDetails"] : $this->getContext($context, "userDetails")), "birthdate", array()), "html", null, true);
            echo "</p>
                                <p>Registration: ";
            // line 42
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["userDetails"]) ? $context["userDetails"] : $this->getContext($context, "userDetails")), "registration", array()), "html", null, true);
            echo "</p>
                                <p>Gender: ";
            // line 43
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["userDetails"]) ? $context["userDetails"] : $this->getContext($context, "userDetails")), "sex", array()), "html", null, true);
            echo "</p>
                            </div>
                            <div class=\"ratings\">
                                <p class=\"pull-right\">15 reviews</p>
                                <p>
                                    <span class=\"glyphicon glyphicon-star\"></span>
                                    <span class=\"glyphicon glyphicon-star\"></span>
                                    <span class=\"glyphicon glyphicon-star\"></span>
                                    <span class=\"glyphicon glyphicon-star\"></span>
                                    <span class=\"glyphicon glyphicon-star\"></span>
                                </p>
                            </div>
                        </div>
                    </div>
                ";
        }
        // line 57
        echo "    
                   
                </div>
            </div>

        </div>

    </div>
";
    }

    public function getTemplateName()
    {
        return "UsersBundle:Users:details.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  122 => 57,  104 => 43,  100 => 42,  96 => 41,  89 => 39,  85 => 38,  75 => 30,  71 => 29,  62 => 27,  57 => 26,  55 => 25,  31 => 3,  28 => 2,  11 => 1,);
    }
}
