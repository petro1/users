<?php

/* UsersBundle:Users:index.html.twig */
class __TwigTemplate_a5542b14f8421ecfba24de2abd9b37653d710422c2874afb5544efaee83ac264 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "UsersBundle:Users:index.html.twig", 1);
        $this->blocks = array(
            'pageContent' => array($this, 'block_pageContent'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_pageContent($context, array $blocks = array())
    {
        // line 3
        echo "    <!-- Page Content -->
    <div class=\"container\">

        <div class=\"row\">

            <div class=\"col-md-3\">
                <p class=\"lead\"><a href=\"/users/web\">Users</a></p>
                <div class=\"list-group\">
                    <a href=\"/users/web/?gender=m\" class=\"list-group-item\">Male</a>
                    <a href=\"/users/web/?gender=f\" class=\"list-group-item\">Female</a>
                </div>
            </div>

            <div class=\"col-md-9\">
                <div class=\"row\">
                    <div style=\"margin-bottom: 10px;margin-left:29px;\">
                    <form method =\"get\" action=\"/users/web\">
                        <input type=\"text\" name=\"name\"/>
                        <button type=\"submit\">Search First Name</button>
                    </form>
                    </div>
                    ";
        // line 24
        if ($this->getAttribute((isset($context["users"]) ? $context["users"] : null), "errors", array(), "any", true, true)) {
            // line 25
            echo "                        ";
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["users"]) ? $context["users"] : $this->getContext($context, "users")), "errors", array()));
            foreach ($context['_seq'] as $context["_key"] => $context["error"]) {
                // line 26
                echo "                            <p class=\"error\">";
                echo twig_escape_filter($this->env, $context["error"], "html", null, true);
                echo "</p>
                        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['error'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 28
            echo "                                             
                    ";
        } else {
            // line 29
            echo "                   
";
            // line 31
            echo "                    <div style=\"float:right\">
                        ";
            // line 32
            if (array_key_exists("currentPage", $context)) {
                // line 33
                echo "                            <p> Page ";
                echo twig_escape_filter($this->env, (isset($context["currentPage"]) ? $context["currentPage"] : $this->getContext($context, "currentPage")), "html", null, true);
                echo " </p>
                        ";
            }
            // line 35
            echo "                    </div>                    
                    </div>

                            ";
            // line 38
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["users"]) ? $context["users"] : $this->getContext($context, "users")));
            foreach ($context['_seq'] as $context["_key"] => $context["user"]) {
                // line 39
                echo "                                <div class=\"col-sm-4 col-lg-4 col-md-4\">
                                    <div class=\"thumbnail\">
                                        <img src=\"http://placehold.it/320x150\" alt=\"\">
                                        <div class=\"caption\">
                                            <h4 class=\"pull-right\">";
                // line 43
                echo twig_escape_filter($this->env, $this->getAttribute($context["user"], "last_name", array()), "html", null, true);
                echo "</h4>
                                            <h4><a href=\"/users/web/user/";
                // line 44
                echo twig_escape_filter($this->env, $this->getAttribute($context["user"], "id", array()), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["user"], "first_name", array()), "html", null, true);
                echo "</a>
                                            </h4>
                                            <p>Birthdate: ";
                // line 46
                echo twig_escape_filter($this->env, $this->getAttribute($context["user"], "birthdate", array()), "html", null, true);
                echo "</p>
                                            <p>Registration date: ";
                // line 47
                echo twig_escape_filter($this->env, $this->getAttribute($context["user"], "registration", array()), "html", null, true);
                echo "</p>
                                            <p>Gender ";
                // line 48
                echo twig_escape_filter($this->env, $this->getAttribute($context["user"], "sex", array()), "html", null, true);
                echo "</p>
                                        </div>
                                        <div class=\"ratings\">
                                            <p class=\"pull-right\">15 reviews</p>
                                            <p>
                                                <span class=\"glyphicon glyphicon-star\"></span>
                                                <span class=\"glyphicon glyphicon-star\"></span>
                                                <span class=\"glyphicon glyphicon-star\"></span>
                                                <span class=\"glyphicon glyphicon-star\"></span>
                                                <span class=\"glyphicon glyphicon-star\"></span>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['user'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 63
            echo "                        ";
        }
        echo "    
                   
                        </div>
                    </div>

                </div>

            </div>
";
    }

    public function getTemplateName()
    {
        return "UsersBundle:Users:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  143 => 63,  122 => 48,  118 => 47,  114 => 46,  107 => 44,  103 => 43,  97 => 39,  93 => 38,  88 => 35,  82 => 33,  80 => 32,  77 => 31,  74 => 29,  70 => 28,  61 => 26,  56 => 25,  54 => 24,  31 => 3,  28 => 2,  11 => 1,);
    }
}
