<?php

/* UsersBundle:Users:edit.html.twig */
class __TwigTemplate_c6d81a9bf70364f22b7a59dce6467cffc8be910e546c9c3195765e43641c106a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "UsersBundle:Users:edit.html.twig", 1);
        $this->blocks = array(
            'pageContent' => array($this, 'block_pageContent'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_pageContent($context, array $blocks = array())
    {
        // line 3
        echo "    <!-- Page Content -->
    <div class=\"container\">

        <div class=\"row\">

            <div class=\"col-md-3\">
                <p class=\"lead\"><a href=\"/users/web\">Users</a></p>
                <div class=\"list-group\">
                    <a href=\"/users/web/?gender=m\" class=\"list-group-item\">Male</a>
                    <a href=\"/users/web/?gender=f\" class=\"list-group-item\">Female</a>
                </div>
            </div>

            <div class=\"col-md-9\">
                <div class=\"row\">
                    
                    <div style=\"margin-bottom: 10px;margin-left:29px;\">
                    <form method =\"get\" action=\"/users/web\">
                        <input type=\"text\" name=\"name\"/>
                        <button type=\"submit\">Search First Name</button>
                    </form>
                    </div>
                    ";
        // line 25
        if ($this->getAttribute((isset($context["users"]) ? $context["users"] : null), "errors", array(), "any", true, true)) {
            // line 26
            echo "                        ";
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["users"]) ? $context["users"] : $this->getContext($context, "users")), "errors", array()));
            foreach ($context['_seq'] as $context["_key"] => $context["error"]) {
                // line 27
                echo "                            <p class=\"error\">";
                echo twig_escape_filter($this->env, $context["error"], "html", null, true);
                echo "</p>
                        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['error'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 29
            echo "                                             
                    ";
        } else {
            // line 30
            echo "                   
                    <p class=\"col-lg-4\">User details</p>                  
                    </div>
                            
                    <div class=\"col-sm-4 col-lg-4 col-md-4\">
                            <div class=\"caption\">
                                ";
            // line 36
            echo             $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
            echo "
                                ";
            // line 37
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
            echo "
                                ";
            // line 38
            echo             $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
            echo "
                            </div>
                    </div>
                ";
        }
        // line 41
        echo "    
                   
                </div>
            </div>

        </div>

    </div>
";
    }

    public function getTemplateName()
    {
        return "UsersBundle:Users:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  98 => 41,  91 => 38,  87 => 37,  83 => 36,  75 => 30,  71 => 29,  62 => 27,  57 => 26,  55 => 25,  31 => 3,  28 => 2,  11 => 1,);
    }
}
