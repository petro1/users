<?php

// ::base.html.twig
return array (
  '9f4f6c0' => 
  array (
    0 => 
    array (
      0 => '@UsersBundle/Resources/public/css/*',
    ),
    1 => 
    array (
      0 => 'cssrewrite',
    ),
    2 => 
    array (
      'output' => '_controller/css/9f4f6c0.css',
      'name' => '9f4f6c0',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
  '9a170f3' => 
  array (
    0 => 
    array (
      0 => '@UsersBundle/Resources/public/js/*',
    ),
    1 => 
    array (
    ),
    2 => 
    array (
      'output' => '_controller/js/9a170f3.js',
      'name' => '9a170f3',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
);
