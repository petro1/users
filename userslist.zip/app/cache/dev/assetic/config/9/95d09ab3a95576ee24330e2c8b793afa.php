<?php

// UsersBundle:Users:details.html.twig
return array (
);
