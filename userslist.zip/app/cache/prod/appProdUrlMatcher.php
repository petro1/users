<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * appProdUrlMatcher.
 *
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appProdUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    /**
     * Constructor.
     */
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($pathinfo)
    {
        $allow = array();
        $pathinfo = rawurldecode($pathinfo);
        $context = $this->context;
        $request = $this->request;

        // users_homepage
        if (rtrim($pathinfo, '/') === '') {
            if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                $allow = array_merge($allow, array('GET', 'HEAD'));
                goto not_users_homepage;
            }

            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'users_homepage');
            }

            return array (  '_controller' => 'UsersBundle\\Controller\\UsersController::indexAction',  '_route' => 'users_homepage',);
        }
        not_users_homepage:

        // users_details
        if (0 === strpos($pathinfo, '/user') && preg_match('#^/user/(?P<userId>(\\d+))$#s', $pathinfo, $matches)) {
            if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                $allow = array_merge($allow, array('GET', 'HEAD'));
                goto not_users_details;
            }

            return $this->mergeDefaults(array_replace($matches, array('_route' => 'users_details')), array (  '_controller' => 'UsersBundle\\Controller\\UsersController::getUserDetailsAction',));
        }
        not_users_details:

        if (0 === strpos($pathinfo, '/edit')) {
            // users_edit
            if (preg_match('#^/edit/(?P<userId>(\\d+))$#s', $pathinfo, $matches)) {
                if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'HEAD'));
                    goto not_users_edit;
                }

                return $this->mergeDefaults(array_replace($matches, array('_route' => 'users_edit')), array (  '_controller' => 'UsersBundle\\Controller\\UsersController::editAction',));
            }
            not_users_edit:

            // users_save
            if (preg_match('#^/edit/(?P<userId>(\\d+))$#s', $pathinfo, $matches)) {
                if ($this->context->getMethod() != 'POST') {
                    $allow[] = 'POST';
                    goto not_users_save;
                }

                return $this->mergeDefaults(array_replace($matches, array('_route' => 'users_save')), array (  '_controller' => 'UsersBundle\\Controller\\UsersController::editAction',));
            }
            not_users_save:

        }

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}
